package com.photos.amy.albrecht.dao;

import com.photos.amy.albrecht.dao.MariaDBConnector;

public class AlbumServices extends MariaDBConnector implements AlbumI {

}
