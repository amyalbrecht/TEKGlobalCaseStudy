package com.photos.amy.albrecht.services;

import com.photos.amy.albrecht.dao.AlbumI;
import com.photos.amy.albrecht.dao.MariaDBConnector;

public class AlbumServices extends MariaDBConnector implements AlbumI {

}
