package com.photos.amy.albrecht.services;

import com.photos.amy.albrecht.dao.MariaDBConnector;
import com.photos.amy.albrecht.dao.TagI;

public class TagServices extends MariaDBConnector implements TagI {

}
