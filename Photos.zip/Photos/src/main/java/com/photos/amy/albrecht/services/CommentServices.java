package com.photos.amy.albrecht.services;

import com.photos.amy.albrecht.dao.CommentI;
import com.photos.amy.albrecht.dao.MariaDBConnector;

public class CommentServices extends MariaDBConnector implements CommentI {

}
