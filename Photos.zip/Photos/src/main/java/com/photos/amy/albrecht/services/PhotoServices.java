package com.photos.amy.albrecht.services;

import com.photos.amy.albrecht.dao.MariaDBConnector;
import com.photos.amy.albrecht.dao.PhotoI;

public class PhotoServices extends MariaDBConnector implements PhotoI {

}
