package com.photos.amy.albrecht.dao;

public interface LikeI {

}
