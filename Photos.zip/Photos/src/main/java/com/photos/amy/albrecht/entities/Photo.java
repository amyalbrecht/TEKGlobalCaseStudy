package com.photos.amy.albrecht.entities;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity 
@Table(name = "photo")
public class Photo {
	
	@Id
	int photoId;
	String photoFileName;	
	String caption;
	int likes;

}
