package com.photos.amy.albrecht.services;

import com.photos.amy.albrecht.dao.LikeI;
import com.photos.amy.albrecht.dao.MariaDBConnector;

public class LikeServices extends MariaDBConnector implements LikeI {

}
