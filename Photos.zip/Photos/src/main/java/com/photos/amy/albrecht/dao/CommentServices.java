package com.photos.amy.albrecht.dao;

import com.photos.amy.albrecht.dao.MariaDBConnector;

public class CommentServices extends MariaDBConnector implements CommentI {

}
